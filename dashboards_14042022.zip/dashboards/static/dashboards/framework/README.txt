
directories and files resulting from bundling the framework
/js/
/media/

files that were changed/added to the framework
*.js