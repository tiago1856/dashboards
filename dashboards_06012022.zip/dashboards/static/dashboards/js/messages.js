export const MSG_OVERRIDE_LAYOUT = "Mudar de layout irá descartar tudo menos o nome. Deseja continuar?";
export const MSG_NO_SAVE = "Sair sem gravar?";
export const MSG_DELETE_QUERY = "Esta operação não é reversivel e qualquer componente que use este query será afectado. Deseja continuar?";

