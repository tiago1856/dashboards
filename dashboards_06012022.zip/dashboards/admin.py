from django.contrib import admin
from .models import Query

admin.site.register(Query)

