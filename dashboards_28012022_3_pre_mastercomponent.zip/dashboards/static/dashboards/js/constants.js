
export const NO_DASHBOARD_TITLE_DEFINED = '<span style="color: red;">Titulo do Dashboard não Definido!</span>';
export const NO_TITLE_DEFINED = '<span style="color: red;">Titulo do Componente não Definido!</span>';
